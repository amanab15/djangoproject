from django.apps import AppConfig


class GrievanceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'grievance'
